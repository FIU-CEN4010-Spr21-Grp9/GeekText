package GeekTextRest;
/**
*  Title: Browse
*  Semester: CEN4010 - Spring 2021
*  @author Shawn Welsh
* 
* I affirm that this program is entirely my own work and none of it is the work
* of any other person. 
* 
* This class provides the browsing framework for the GeekText application group
* project for group 9
* 
*/
public class Browse
{
	private int genreID;
	private int booksPerPage;
	// collection of book objects private ??? books;
	
	// TO DO
	// Start a new search
	
	// Clear existing search, start another (call previous "new search")
	
	// Sort an existing search
	
	// Page an existing search
	
	
}
