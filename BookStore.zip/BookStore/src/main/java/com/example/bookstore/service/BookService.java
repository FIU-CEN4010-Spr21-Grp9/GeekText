package com.example.bookstore.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bookstore.model.Book;
import com.example.bookstore.repo.BookRepo;



@Service
public class BookService 
{
	
	private final BookRepo bookrepo;
	
	
	@Autowired
	public BookService(BookRepo bookrepo) 
	{
		this.bookrepo = bookrepo;
	}
	

	public List<Book> findAllBooks()
	{
		return bookrepo.findAll();
	}
	

	public Book getBookByID(Integer bookID)
	{
		return bookrepo.getOne(bookID);
	}
}
